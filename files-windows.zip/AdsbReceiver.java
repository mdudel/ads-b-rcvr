package com.adsb.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Spawns rtl_adsb (or rtl_adsb.exe on Windows) as a subprocess and reads
 * ADS-B frames from its stdout.
 *
 * rtl_adsb outputs frames in AVR format by default:
 *   *<hex_bytes>;
 *
 * Each complete line is treated as one frame and forwarded to all registered
 * {@link FrameForwarder} instances.
 *
 * Windows notes:
 *  - The executable is looked up as "rtl_adsb.exe" on Windows.
 *  - An optional --rtl-path argument can point to the folder containing
 *    rtl_adsb.exe if it is not on the system PATH.
 *  - stdout is read with the system default charset (usually CP1252 / UTF-8
 *    on modern Windows); AVR frames are pure ASCII so this is fine.
 */
public class AdsbReceiver {

    private static final boolean IS_WINDOWS =
            System.getProperty("os.name", "").toLowerCase().contains("win");

    private final int     deviceIndex;
    private final String  gain;
    private final String  format;
    private final boolean verbose;
    /** Optional path to the directory containing rtl_adsb.exe */
    private final String  rtlPath;

    public AdsbReceiver(int deviceIndex, String gain, String format,
                        boolean verbose, String rtlPath) {
        this.deviceIndex = deviceIndex;
        this.gain        = gain;
        this.format      = format;
        this.verbose     = verbose;
        this.rtlPath     = rtlPath;
    }

    /**
     * Starts rtl_adsb and blocks until the process exits (or is interrupted).
     * Each received frame is forwarded to every forwarder in {@code forwarders}.
     */
    public void start(List<? extends AutoCloseable> forwarders) throws Exception {
        ProcessBuilder pb = buildProcess();
        pb.redirectErrorStream(false); // keep stderr separate

        System.out.println("[INFO] Starting: " + String.join(" ", pb.command()));
        Process proc = pb.start();

        // Drain stderr in a background daemon thread to prevent pipe blocking
        Thread stderrDrainer = new Thread(() -> {
            try (BufferedReader err = new BufferedReader(
                    new InputStreamReader(proc.getErrorStream(), Charset.defaultCharset()))) {
                String line;
                while ((line = err.readLine()) != null) {
                    System.err.println("[rtl_adsb] " + line);
                }
            } catch (Exception ignored) {}
        }, "stderr-drainer");
        stderrDrainer.setDaemon(true);
        stderrDrainer.start();

        // Read AVR frames from stdout — one frame per line
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(proc.getInputStream(), Charset.defaultCharset()))) {

            String line;
            long frameCount = 0;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Normalise line endings: always send \n (Unix-style)
                // downstream consumers (VRS, dump1090, etc.) expect this.
                byte[] frame = (line + "\n").getBytes(StandardCharsets.US_ASCII);

                if (verbose) {
                    System.out.printf("[FRAME %06d] %s%n", ++frameCount, line);
                }

                for (AutoCloseable fwd : forwarders) {
                    if (fwd instanceof FrameForwarder ff) {
                        try {
                            ff.forward(frame);
                        } catch (Exception e) {
                            System.err.println("[WARN] Forward error ("
                                    + fwd.getClass().getSimpleName() + "): " + e.getMessage());
                        }
                    }
                }
            }
        }

        int exit = proc.waitFor();
        System.out.printf("[INFO] rtl_adsb exited with code %d%n", exit);
    }

    // -------------------------------------------------------------------------

    private ProcessBuilder buildProcess() {
        List<String> cmd = new ArrayList<>();

        // Resolve executable name / path
        String exe = IS_WINDOWS ? "rtl_adsb.exe" : "rtl_adsb";
        if (rtlPath != null && !rtlPath.isBlank()) {
            exe = rtlPath + File.separator + exe;
        }
        cmd.add(exe);

        cmd.add("-d");
        cmd.add(String.valueOf(deviceIndex));

        if (!"auto".equalsIgnoreCase(gain)) {
            cmd.add("-g");
            cmd.add(gain);
        }

        if ("raw".equalsIgnoreCase(format)) {
            cmd.add("-V");
        }

        ProcessBuilder pb = new ProcessBuilder(cmd);

        // On Windows, inherit the parent environment so PATH is available
        pb.environment().putAll(System.getenv());

        return pb;
    }
}
